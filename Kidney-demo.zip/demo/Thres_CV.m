function [P,u2]=Thres_CV(I)
% -- resize original image
%    s = 512./min(size(I,1),size(I,2));
%    if s<1
%        I = imresize(I,s);
%    end
% figure,imshow(I,[]),title('I')
   I = imcrop(I,[5 5 250 250]);
   M = size(I,1);
   N = size(I,2);
if size(I,3) == 3
    P = rgb2gray(uint8(I));
    P = double(P);
 elseif size(I,3) == 2
     P = 0.5.*(double(I(:,:,1))+double(I(:,:,2)));
    else
     P = double(I);
 end
     P = P./max(max(abs(P)));
%%
% -- looping
        %% Standard ChanVese 
        dt = 0.1;  % time step
        alpha = 0.01; % parameter alpha
        lamda = alpha * sqrt(pi)/sqrt(dt);
        
        % -- initial contour
        u1 = zeros(M,N);
        S = 100;
        u1(S:M-S,S:N-S) = ones(M-2*S+1,N-2*S+1);
        u2 = ones(M,N)-u1;
        % -- plot images
        figure();
%         subplot(2,2,1); imshow(I); title('Input Image');
%         subplot(2,2,2); imshow(P); title('Noised Image');
        imshow(P); hold; contour(u1, [0.5 0.5], 'r','LineWidth',0.5); title('initial contour');
        figure,imshow(P,[]);title('Segmentation')   
        u1p = - ones(size(u1)); % previous u1
        u2p = - ones(size(u2)); % previous u2
        change = 1;              
        k = 0;
        while change > 1e-12
            change = norm(u1-u1p) + norm(u2-u2p);
            u1p = u1;
            u2p = u2;
            k = k+1;
            [f1,f2] = daterm(P,u1,u2);
            [uh1,uh2] =HeatConv(dt,u1,u2); % convolution with heat kernel
            index1 = f1+lamda*uh2;
            index2 = f2+lamda*uh1;
            u1 = double(index1<=index2); % thresholding if u1>u2 then u1=1 vise versa
            u2 = 1-u1;

            imshow(P);
            hold on
            contour(u1, [0.5 0.5], 'r','LineWidth',0.1);
            hold off
            axis off 
            axis square
            title([num2str(k) ' Iterations']);
            drawnow
%             pause(0.5);
        end

        figure();
        imshow(P);
        hold on
        contour(u1, [0.5 0.5], 'r','LineWidth',0.5);
        hold off
        title([num2str(k) ' Iterations']);

        
        
        
        
        
        
        